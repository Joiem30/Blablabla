// =======================================
// ExcelFixer Preview
// File: js/preview.js
// =======================================


// Preview Area

const previewArea =
document.getElementById("previewArea");



// File Input

const excelFile =
document.getElementById("excelFile");



// Listen for file selection

if(excelFile){

    excelFile.addEventListener(
        "change",
        previewFile
    );

}



// =======================================
// Preview File
// =======================================

async function previewFile(){


    const file =
    excelFile.files[0];


    if(!file){

        previewArea.innerHTML =
        "<p>No file selected.</p>";

        return;

    }


    previewArea.innerHTML =

    `
        <h3>Loading Preview...</h3>
    `;



    try{


        // File Information

        let html =

        `
        <h3>Excel File Preview</h3>

        <hr>

        <p><strong>File Name:</strong> ${file.name}</p>

        <p><strong>File Size:</strong>
        ${(file.size/1024).toFixed(2)} KB
        </p>

        <p><strong>File Type:</strong>
        ${file.type}
        </p>

        <p><strong>Last Modified:</strong>
        ${new Date(file.lastModified).toLocaleString()}
        </p>
        `;



        // If ExcelJS is loaded

        if(typeof ExcelJS !== "undefined"){

            const workbook =
            new ExcelJS.Workbook();

            const buffer =
            await file.arrayBuffer();

            await workbook.xlsx.load(buffer);

            html += "<hr>";
            html += "<h4>Worksheets</h4>";
            html += "<ul>";

            workbook.eachSheet(sheet=>{

                html +=
                `<li>${sheet.name}</li>`;

            });

            html += "</ul>";

        }


        previewArea.innerHTML =
        html;


    }

    catch(error){

        console.error(error);

        previewArea.innerHTML =

        `
        <h3>Preview Error</h3>

        <p>${error.message}</p>
        `;

    }

}