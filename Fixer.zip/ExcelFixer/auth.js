// ==============================
// ExcelFixer Authentication
// File: js/auth.js
// ==============================

import {
    signInUser,
    createUserAccount,
    logoutUser,
    auth
}
from "./firebase.js";
// Login Function

const loginForm = document.getElementById("loginForm");


if(loginForm){

    loginForm.addEventListener("submit", async (e)=>{

        e.preventDefault();


        const email =
        document.getElementById("email").value;


        const password =
        document.getElementById("password").value;



        try{


            const userCredential =
            await signInUser(email,password);



            const user =
            userCredential.user;



            console.log(
                "Login Successful:",
                user.email
            );



            // Save login session

            localStorage.setItem(
                "excelFixerUser",
                user.email
            );



            // Redirect dashboard

            window.location.href =
            "dashboard.html";



        }
        catch(error){


            console.error(error);


            alert(
                "Login Failed: "
                + error.message
            );


        }


    });


}





// ==============================
// Register Function
// ==============================


const registerForm =
document.getElementById("registerForm");



if(registerForm){


registerForm.addEventListener("submit",
async(e)=>{


    e.preventDefault();



    const email =
    document.getElementById("email").value;



    const password =
    document.getElementById("password").value;



    try{


        const userCredential =
        await createUserAccount(
            email,
            password
        );



        console.log(
            "Account Created",
            userCredential.user.email
        );



        alert(
            "Registration successful!"
        );



        window.location.href =
        "login.html";



    }
    catch(error){


        alert(
            "Registration Failed: "
            + error.message
        );


    }



});


}





// ==============================
// Dashboard User Display
// ==============================


const username =
document.getElementById("username");



if(username){


    const savedUser =
    localStorage.getItem(
        "excelFixerUser"
    );



    if(savedUser){


        username.innerText =
        savedUser.split("@")[0];


    }
    else{


        username.innerText =
        "Guest";


    }


}





// ==============================
// Logout
// ==============================


const logoutBtn =
document.querySelector(".logout");



if(logoutBtn){


logoutBtn.addEventListener(
"click",
async()=>{


    try{


        await logoutUser();



        localStorage.removeItem(
            "excelFixerUser"
        );



        window.location.href =
        "login.html";


    }
    catch(error){


        console.log(error);


    }


});


}