// =======================================
// ExcelFixer Upload System
// File: js/upload.js
// =======================================


// Selected Excel file

let uploadedFile = null;


// Elements

const fileInput =
document.getElementById("excelFile");

const uploadBtn =
document.getElementById("uploadBtn");

const previewArea =
document.getElementById("previewArea");

const totalUploads =
document.getElementById("totalUploads");




// Upload Button

if(uploadBtn){

    uploadBtn.addEventListener(
        "click",
        uploadExcel
    );

}




// =======================================
// Upload Function
// =======================================

function uploadExcel(){


    if(!fileInput.files.length){

        alert(
            "Please choose an Excel file."
        );

        return;

    }



    const file =
    fileInput.files[0];



    // Validate Extension

    const allowed = [

        ".xlsx",

        ".xls"

    ];


    const filename =
    file.name.toLowerCase();



    const valid =
    allowed.some(
        ext=>filename.endsWith(ext)
    );



    if(!valid){

        alert(
        "Only Excel (.xlsx or .xls) files are allowed."
        );

        return;

    }



    uploadedFile = file;



    // Pass file to excelFixer.js

    if(typeof setExcelFile === "function"){

        setExcelFile(file);

    }



    // Update uploads

    updateUploadCounter();



    // Preview

    showPreview(file);



    alert(
        "Excel uploaded successfully!"
    );

}





// =======================================
// Preview
// =======================================

function showPreview(file){


    if(!previewArea) return;



    previewArea.innerHTML =

    `
        <h3>Uploaded File</h3>

        <p><strong>Name:</strong> ${file.name}</p>

        <p><strong>Size:</strong>
        ${(file.size/1024).toFixed(2)} KB
        </p>

        <p><strong>Type:</strong>
        ${file.type || "Excel Workbook"}
        </p>

        <p style="color:green;">
        ✔ Ready for repair
        </p>
    `;


}





// =======================================
// Upload Counter
// =======================================

function updateUploadCounter(){


    let uploads =
    Number(
        localStorage.getItem(
            "totalUploads"
        )
    ) || 0;



    uploads++;



    localStorage.setItem(
        "totalUploads",
        uploads
    );



    if(totalUploads){

        totalUploads.innerText =
        uploads;

    }


}





// =======================================
// Load Dashboard Statistics
// =======================================

window.addEventListener(
"load",
()=>{


    if(totalUploads){

        totalUploads.innerText =

        localStorage.getItem(
            "totalUploads"
        ) || 0;

    }



    const repaired =
    document.getElementById(
        "repairedFiles"
    );



    if(repaired){

        repaired.innerText =

        localStorage.getItem(
            "repairedFiles"
        ) || 0;

    }



    const errors =
    document.getElementById(
        "errorsFixed"
    );



    if(errors){

        errors.innerText =

        localStorage.getItem(
            "errorsFixed"
        ) || 0;

    }



    const downloads =
    document.getElementById(
        "downloads"
    );



    if(downloads){

        downloads.innerText =

        localStorage.getItem(
            "excelDownloads"
        ) || 0;

    }


});