// =======================================
// ExcelFixer Repair Engine
// Browser Version using ExcelJS
// =======================================

let repairedFile = null;

// =======================================
// Repair Button
// =======================================

const repairBtn = document.getElementById("repairBtn");

if (repairBtn) {

    repairBtn.addEventListener("click", async () => {

        const fileInput = document.getElementById("excelFile");
        const file = fileInput.files[0];

        if (!file) {
            alert("Please upload an Excel file first.");
            return;
        }

        await repairExcel(file);

    });

}

// =======================================
// Main Repair Function
// =======================================

async function repairExcel(file) {

    try {

        showProgress("Reading Excel file...");

        const workbook = new ExcelJS.Workbook();

        const buffer = await file.arrayBuffer();

        await workbook.xlsx.load(buffer);

        showProgress("Repairing workbook...");

        let errorCount = 0;

        workbook.eachSheet((worksheet) => {

            // =============================
            // Print Scaling
            // =============================

            if (document.getElementById("printScaling")?.checked) {

                worksheet.pageSetup = {

                    paperSize: 9,
                    orientation: "landscape",

                    fitToPage: true,
                    fitToWidth: 1,
                    fitToHeight: 0,

                    margins: {

                        left: 0.5,
                        right: 0.5,
                        top: 0.75,
                        bottom: 0.75,
                        header: 0.3,
                        footer: 0.3

                    },

                    horizontalCentered: true,
                    verticalCentered: false

                };

            }

            // =============================
            // Automatic Page Breaks
            // =============================

            if (document.getElementById("pageBreaks")?.checked) {

                worksheet.eachRow((row, rowNumber) => {

                    if (rowNumber % 50 === 0) {
                        row.addPageBreak();
                    }

                });

            }

            // =============================
            // Auto Resize Columns
            // =============================

            worksheet.columns.forEach((column) => {

                let maxLength = 10;

                column.eachCell({ includeEmpty: true }, (cell) => {

                    const value = cell.value ? cell.value.toString() : "";

                    if (value.length > maxLength) {
                        maxLength = value.length;
                    }

                });

                column.width = maxLength + 3;

            });

            // =============================
            // Fix Rows & Cells
            // =============================

            worksheet.eachRow((row) => {

                row.height = 20;

                row.eachCell((cell) => {

                    cell.alignment = {

                        horizontal: "left",
                        vertical: "middle",
                        wrapText: true

                    };

                    cell.font = {

                        name: "Arial",
                        size: 11

                    };

                    errorCount++;

                });

            });

        });

        showProgress("Creating repaired workbook...");

        const output = await workbook.xlsx.writeBuffer();

        repairedFile = new File(
            [output],
            "Fixed_" + file.name,
            {
                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            }
        );

        if (typeof setRepairedFile === "function") {
            setRepairedFile(repairedFile);
        }

        localStorage.setItem("errorsFixed", errorCount);

        showProgress("Repair completed!");

        alert("Excel repaired successfully!");

    }
    catch (error) {

        console.error(error);

        alert("Repair failed: " + error.message);

    }

}

// =======================================
// Progress Display
// =======================================

function showProgress(message) {

    const preview = document.getElementById("previewArea");

    if (preview) {

        preview.innerHTML = `
            <h3>${message}</h3>
            <progress value="70" max="100"></progress>
        `;

    }

}