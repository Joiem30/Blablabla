// =======================================
// ExcelFixer Firebase Configuration
// =======================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";

import {
    getAuth,
    signInWithEmailAndPassword,
    createUserWithEmailAndPassword,
    signOut
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

import {
    getFirestore
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

import {
    getStorage
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";

const firebaseConfig = {

    apiKey: "AIzaSyAQHInCLgulzy4nGB0upvVAqSNeOHxjncs",

    authDomain: "fixer-c9df0.firebaseapp.com",

    projectId: "fixer-c9df0",

    storageBucket: "fixer-c9df0.firebasestorage.app",

    messagingSenderId: "18379341463",

    appId: "1:18379341463:web:608000b78769f05ad333d2"

};

const app = initializeApp(firebaseConfig);

const auth = getAuth(app);

const db = getFirestore(app);

const storage = getStorage(app);

async function signInUser(email,password){

    return signInWithEmailAndPassword(
        auth,
        email,
        password
    );

}

async function createUserAccount(email,password){

    return createUserWithEmailAndPassword(
        auth,
        email,
        password
    );

}

async function logoutUser(){

    return signOut(auth);

}

export {

    app,
    auth,
    db,
    storage,
    signInUser,
    createUserAccount,
    logoutUser

};