// ==============================
// ExcelFixer Download System
// File: js/download.js
// ==============================


// Store repaired file temporarily

let repairedExcelFile = null;



// Receive repaired file from excelFixer.js

function setRepairedFile(file){

    repairedExcelFile = file;

    console.log(
        "Repaired file ready:",
        file.name
    );

}





// Download Button

const downloadBtn =
document.getElementById("downloadBtn");



if(downloadBtn){


downloadBtn.addEventListener(
"click",
()=>{


    if(!repairedExcelFile){


        alert(
            "No repaired file available. Please repair an Excel file first."
        );


        return;


    }



    downloadFile(
        repairedExcelFile
    );



});


}




// ==============================
// Download Function
// ==============================


function downloadFile(file){


    try{


        const url =
        URL.createObjectURL(file);



        const link =
        document.createElement("a");



        link.href = url;



        link.download =
        "ExcelFixer_Repaired_" + file.name;



        document.body.appendChild(link);



        link.click();



        document.body.removeChild(link);



        URL.revokeObjectURL(url);



        updateDownloadCount();



        console.log(
            "Download completed"
        );



    }
    catch(error){


        console.error(
            "Download Error:",
            error
        );


        alert(
            "Unable to download file."
        );


    }


}





// ==============================
// Download Counter
// ==============================


function updateDownloadCount(){


    let count =
    localStorage.getItem(
        "excelDownloads"
    );



    if(!count){

        count = 0;

    }



    count++;



    localStorage.setItem(
        "excelDownloads",
        count
    );



    const downloadDisplay =
    document.getElementById(
        "downloads"
    );



    if(downloadDisplay){


        downloadDisplay.innerText =
        count;


    }


}





// ==============================
// Firebase Upload Placeholder
// ==============================


async function saveDownloadHistory(file){


    /*
    
    Later connect this to Firestore:

    {
        filename:file.name,
        date:new Date(),
        user:user.email,
        action:"download"
    }

    */


    console.log(
        "Saving download history:",
        file.name
    );


}