const firebaseConfig={

apiKey:"AIzaSyC1G1XE12A7vf3Ng9fvZLqvfN3xFSSTALQ",

authDomain:"encoderl.firebaseapp.com",

projectId:"encoderl",

storageBucket:"encoderl.firebasestorage.app",

messagingSenderId:"413196783734",

appId:"1:413196783734:web:fe82a7c84eb96ebf5d8f57"

};

firebase.initializeApp(firebaseConfig);

const db = firebase.firestore();