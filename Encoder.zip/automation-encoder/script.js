document.addEventListener("DOMContentLoaded", () => {

const table = document.getElementById("sheet");
const parent = document.getElementById("parentHeader");
const child = document.getElementById("childHeader");
const body = table.querySelector("tbody");
const title = document.getElementById("tableTitle");

let columns = [];

// Tracks the last row the user clicked into, so "Add Subrow"
// knows where to insert the new row.
let activeRow = null;

/* =========================================
   RENDER HEADERS
========================================= */
function render(){

    parent.innerHTML="";
    child.innerHTML="";

    let hasChildren=false;

    columns.forEach(col=>{

        const th=document.createElement("th");

        th.innerText=col.title;

        if(col.children.length){

            hasChildren=true;

            th.colSpan=col.children.length;

            parent.appendChild(th);

            col.children.forEach(sub=>{

                const childTh=document.createElement("th");

                childTh.innerText=sub;

                child.appendChild(childTh);

            });

        }else{

            th.rowSpan=2;

            parent.appendChild(th);

        }

    });

    if(!hasChildren){

        child.style.display="none";

    }else{

        child.style.display="table-row";

    }

}

/* =========================================
   GET TOTAL COLUMN COUNT
========================================= */
function getTotalColumns() {

    let total = 0;

    columns.forEach(c => {
        total += c.children.length ? c.children.length : 1;
    });

    return total;
}

/* =========================================
   GET STARTING CELL INDEX FOR A COLUMN
   (sum of slots occupied by all columns before it)
========================================= */
function getColumnStartIndex(colIndex) {

    let idx = 0;

    for (let i = 0; i < colIndex; i++) {
        idx += columns[i].children.length ? columns[i].children.length : 1;
    }

    return idx;
}

/* =========================================
   CREATE EDITABLE CELL
========================================= */
function createCell(value = "") {

    const td = document.createElement("td");
    td.contentEditable = true;
    td.innerText = value;

    return td;
}

/* =========================================
   ADD COLUMN
========================================= */
document.getElementById("addColumn").onclick = () => {

    const name = prompt("Column Name");

    if (!name) return;

    columns.push({
        title: name,
        children: []
    });

    render();

    body.querySelectorAll("tr").forEach(row => {
        row.appendChild(createCell());
    });

};

/* =========================================
   ADD ROW (always at the end)
========================================= */
document.getElementById("addRow").onclick = () => {

    insertRow(body.querySelectorAll("tr").length);

};

/* =========================================
   ADD SUB ROW
   Inserts a new row right below the row that
   was last clicked/edited in the body.
   Falls back to adding at the end if no row
   has been selected yet.
========================================= */
document.getElementById("addSubRow").onclick = () => {

    const rows = Array.from(body.querySelectorAll("tr"));

    if (!activeRow || !rows.includes(activeRow)) {

        insertRow(rows.length);

        return;

    }

    const rowIndex = rows.indexOf(activeRow);

    const newRow = insertRow(rowIndex + 1);

    activeRow = newRow;

    if (newRow && newRow.cells.length > 0) {
        newRow.cells[0].focus();
    }

};

/* =========================================
   TRACK ACTIVE ROW
   Whenever the user clicks/focuses a cell,
   remember which row it belongs to.
========================================= */
body.addEventListener("focusin", (e) => {

    const cell = e.target.closest("td");

    if (!cell) return;

    activeRow = cell.parentElement;

});

body.addEventListener("click", (e) => {

    const cell = e.target.closest("td");

    if (!cell) return;

    activeRow = cell.parentElement;

});

/* =========================================
   ADD SUB COLUMN
========================================= */
document.getElementById("addSubColumn").onclick = () => {

    const parentName = prompt("Parent Column");

    if (!parentName) return;

    const childName = prompt("Sub Column Name");

    if (!childName) return;

    const parentIndex = columns.findIndex(
        c => c.title === parentName
    );

    if (parentIndex === -1) {

        alert("Parent column not found.");

        return;

    }

    const column = columns[parentIndex];

    // How many cell-slots this column currently occupies
    // (1 if it has no children yet, otherwise its children count)
    const currentSlots = column.children.length ? column.children.length : 1;

    // Where the new sub-column's cell should be inserted:
    // right after all slots this column already owns
    const startIndex = getColumnStartIndex(parentIndex);
    const insertIndex = startIndex + currentSlots;

    column.children.push(childName);

    render();

    body.querySelectorAll("tr").forEach(row => {

        const td = createCell();

        row.insertBefore(td, row.cells[insertIndex] || null);

    });

};

/* =========================================
   DELETE LAST ROW
========================================= */
document.getElementById("deleteRow").onclick = () => {

    const rows = body.querySelectorAll("tr");

    if (rows.length === 0) {
        alert("No rows to delete.");
        return;
    }

    const lastRow = rows[rows.length - 1];

    if (activeRow === lastRow) {
        activeRow = null;
    }

    body.removeChild(lastRow);

};

/* =========================================
   DELETE LAST COLUMN
========================================= */
document.getElementById("deleteColumn").onclick = () => {

    if (columns.length === 0) {
        alert("No columns to delete.");
        return;
    }

    const removed = columns.pop();

    render();

    const removeCount = removed.children.length
        ? removed.children.length
        : 1;

    body.querySelectorAll("tr").forEach(row => {

        for (let i = 0; i < removeCount; i++) {

            if (row.cells.length > 0) {
                row.deleteCell(row.cells.length - 1);
            }

        }

    });

};

/* =========================================
   INSERT ROW
   Returns the newly created row element.
========================================= */
function insertRow(position) {

    const rows = body.querySelectorAll("tr");

    if (position < 0 || position > rows.length) {
        alert("Invalid row position");
        return null;
    }

    const tr = document.createElement("tr");

    for (let i = 0; i < getTotalColumns(); i++) {
        tr.appendChild(createCell());
    }

    if (position === rows.length) {
        body.appendChild(tr);
    } else {
        body.insertBefore(tr, rows[position]);
    }

    return tr;

}

/* =========================================
   INSERT COLUMN
========================================= */
function insertColumn(position) {

    const name = prompt("Column Name");

    if (!name) return;

    columns.splice(position, 0, {
        title: name,
        children: []
    });

    render();

    body.querySelectorAll("tr").forEach(row => {

        const td = createCell();

        if (position >= row.cells.length) {
            row.appendChild(td);
        } else {
            row.insertBefore(td, row.cells[position]);
        }

    });

}

/* =========================================
   SAVE TO FIRESTORE
   NOTE: Firestore does NOT support nested arrays
   (an array containing arrays). The old code built
   `rows` as an array of arrays (one array per row),
   which Firestore rejects with:
   "Nested arrays are not supported".
   Fix: wrap each row in an object, e.g. { cells: [...] },
   so we end up with an array of objects instead.
========================================= */
async function saveToFirestore() {

    const rows = [];

    body.querySelectorAll("tr").forEach(tr => {

        const cells = [];

        tr.querySelectorAll("td").forEach(td => {
            cells.push(td.innerText);
        });

        // Wrap in an object — Firestore allows arrays of
        // objects, just not arrays of arrays.
        rows.push({ cells: cells });

    });

    const data = {
        title: title.value,
        columns: columns,
        rows: rows,
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    };

    await db.collection("tables").doc("table1").set(data);

}

/* =========================================
   SAVE BUTTON
========================================= */
document.getElementById("save").onclick = async () => {

    try {

        await saveToFirestore();

        alert("Saved successfully to Firestore!");

    } catch (error) {

        console.error(error);

        alert("Error saving data! " + (error && error.message ? error.message : ""));

    }

};

/* =========================================
   LOAD FROM FIRESTORE
   Rows are now stored as [{ cells: [...] }, ...],
   so unwrap `.cells` back into a flat array when
   rendering into the table.
========================================= */
async function loadFromFirestore() {

    try {

        const doc = await db.collection("tables").doc("table1").get();

        if (!doc.exists) return;

        const data = doc.data();

        title.value = data.title || "";
        columns = data.columns || [];

        render();

        body.innerHTML = "";
        activeRow = null;

        (data.rows || []).forEach(r => {

            // Support both the new format ({ cells: [...] })
            // and the old raw-array format, in case there's
            // legacy data already saved (from before this fix,
            // if it ever succeeded) or data saved by other code.
            const cellValues = Array.isArray(r) ? r : (r.cells || []);

            const tr = document.createElement("tr");

            cellValues.forEach(cell => {
                tr.appendChild(createCell(cell));
            });

            body.appendChild(tr);

        });

    } catch (error) {

        console.error(error);

    }

}

/* =========================================
   DOWNLOAD EXCEL (with orientation option)
========================================= */
document.getElementById("download").onclick = async () => {

    try {

        // Always get the latest saved data
        await loadFromFirestore();

        const wb = XLSX.utils.table_to_book(table);

        const sheetName = wb.SheetNames[0];
        const ws = wb.Sheets[sheetName];

        // Get selected orientation ("portrait" or "landscape")
        const orientation = document.getElementById("pageOrientation").value;

        // Apply page setup for print/orientation
        ws["!pageSetup"] = {
            orientation: orientation,
            fitToWidth: 1,
            fitToHeight: 0
        };

        // Optional: tell Excel to scale-to-fit the page width
        ws["!margins"] = {
            left: 0.5,
            right: 0.5,
            top: 0.5,
            bottom: 0.5,
            header: 0.3,
            footer: 0.3
        };

        XLSX.writeFile(
            wb,
            (title.value || "Table") + ".xlsx",
            { bookType: "xlsx", cellStyles: true }
        );

    } catch (error) {

        console.error(error);

        alert("Download failed.");

    }

};

/* =========================================
   INITIAL LOAD
========================================= */
(async () => {
    await loadFromFirestore();
})();

});